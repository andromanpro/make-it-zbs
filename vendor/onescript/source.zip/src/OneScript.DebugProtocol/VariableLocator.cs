﻿/*----------------------------------------------------------
This Source Code Form is subject to the terms of the 
Mozilla Public License, v.2.0. If a copy of the MPL 
was not distributed with this file, You can obtain one 
at http://mozilla.org/MPL/2.0/.
----------------------------------------------------------*/
using System;
using System.Collections;
using System.Collections.Generic;

namespace OneScript.DebugProtocol
{
    public interface IVariableLocator : IEnumerable<Variable>
    {
        int Count { get; }

        Variable this[int index] { get; }

        void Hydrate(IDebuggerService process);

        IVariableLocator CreateChildLocator(int variableIndex);
    }

    public class VariableLocator : IVariableLocator
    {

        private int[] _path;
        private readonly int _threadId;
        private readonly int _stackFrameIndex;

        private Variable[] _variables;

        private VariableLocator(VariableLocator parent, int variableIndex)
        {
            _stackFrameIndex = parent._stackFrameIndex;
            _threadId = parent._threadId;
            _path = new int[parent._path.Length + 1];
            Array.Copy(parent._path, _path, parent._path.Length);
            _path[parent._path.Length] = variableIndex;
        }

        public VariableLocator(int threadId, int stackFrameIndex, int variableIndex)
        {
            _threadId = threadId;
            _stackFrameIndex = stackFrameIndex;
            _path = new int[] { variableIndex };
        }

        public Variable this[int index]
        {
            get
            {
                ThrowIfNoVariables();

                return _variables[index];
            }
        }

        public int Count
        {
            get
            {
                ThrowIfNoVariables();
                return _variables.Length;
            }
        }

        public IEnumerator<Variable> GetEnumerator()
        {
            ThrowIfNoVariables();

            return ((IEnumerable<Variable>) _variables).GetEnumerator();
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }

        private void ThrowIfNoVariables()
        {
            if (_variables == null)
                throw new InvalidOperationException("No variables aquired yet");
        }

        void IVariableLocator.Hydrate(IDebuggerService process)
        {
            if(_variables != null)
                return;
            var variables = process.GetVariables(_threadId, _stackFrameIndex, _path);
            _variables = variables;
        }

        IVariableLocator IVariableLocator.CreateChildLocator(int variableIndex)
        {
            return new VariableLocator(this, variableIndex);
        }
    }
}
