/*----------------------------------------------------------
This Source Code Form is subject to the terms of the 
Mozilla Public License, v.2.0. If a copy of the MPL 
was not distributed with this file, You can obtain one 
at http://mozilla.org/MPL/2.0/.
----------------------------------------------------------*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

using ScriptEngine.Machine;
using ScriptEngine.Machine.Contexts;
using ScriptEngine.HostedScript.Library.ValueTable;
using ScriptEngine.Machine.Reflection;
using ScriptEngine.Machine.Values;
using MethodInfo = ScriptEngine.Machine.MethodInfo;

namespace ScriptEngine.HostedScript.Library
{
    /// <summary>
    /// Рефлектор предназначен для получения метаданных объектов во время выполнения.
    /// Как правило, рефлексия используется для проверки наличия у объекта определенных свойств/методов.
    /// В OneScript рефлексию можно применять для вызова методов объектов по именам методов.
    /// </summary>
    [ContextClass("Рефлектор","Reflector")]
    public class ReflectorContext : AutoContext<ReflectorContext>
    {
        /// <summary>
        /// Вызывает метод по его имени.
        /// </summary>
        /// <param name="target">Объект, метод которого нужно вызвать.</param>
        /// <param name="methodName">Имя метода для вызова</param>
        /// <param name="arguments">Массив аргументов, передаваемых методу. Следует учесть, что все параметры нужно передавать явно, в том числе необязательные.</param>
        /// <returns>Если вызывается функция, то возвращается ее результат. В противном случае возвращается Неопределено.</returns>
        [ContextMethod("ВызватьМетод", "CallMethod")]
        public IValue CallMethod(IRuntimeContextInstance target, string methodName, ArrayImpl arguments = null)
        {
            var methodIdx = target.FindMethod(methodName);
            var methInfo = target.GetMethodInfo(methodIdx);

            var argValues = arguments?.ToArray() ?? Array.Empty<IValue>();
            // ArrayImpl не может (не должен!) содержать null или NotAValidValue

            var argsToPass = target.DynamicMethodSignatures ? argValues : GetArgsToPass(argValues, methInfo);

            IValue retValue = ValueFactory.Create();
            if (methInfo.IsFunction)
            {
                target.CallAsFunction(methodIdx, argsToPass, out retValue);
            }
            else
            {
                target.CallAsProcedure(methodIdx, argsToPass);
            }

            if (arguments != null)
            {
                for (int i = 0; i < argsToPass.Length; i++)
                {
                    if (i < arguments.Count())
                    {
                        arguments.Set(i, argsToPass[i]?.GetRawValue());
                    }
                }
            }

            return retValue;
        }

        private static IValue[] GetArgsToPass(IValue[] argValues, MethodInfo methInfo)
        {
            var methArgCount = methInfo.ArgCount;
            if (argValues.Length > methArgCount)
                throw RuntimeException.TooManyArgumentsPassed();

            var methodParams = methInfo.Params;
            var argsToPass = new IValue[methArgCount];

            int i = 0;
            for (; i < argValues.Length; i++)
            {
                if (methodParams[i].IsByValue)
                    argsToPass[i] = argValues[i];
                else
                    argsToPass[i] = Variable.Create(argValues[i], string.Empty); // имя не нужно
            }
            for (; i < methArgCount; i++)
            {
                if (!methodParams[i].HasDefaultValue)
                    throw RuntimeException.TooFewArgumentsPassed();

                argsToPass[i] = methodParams[i].DefaultValue;
            }

            return argsToPass;
        }

        /// <summary>
        /// Проверяет существование указанного метода у переданного объекта.
        /// </summary>
        /// <param name="target">Объект, из которого получаем таблицу методов.</param>
        /// <param name="methodName">Имя метода для вызова</param>
        /// <returns>Истина, если метод существует, и Ложь в обратном случае.</returns>
        [ContextMethod("МетодСуществует", "MethodExists")]
        public bool MethodExists(IValue target, string methodName)
        {
            if(target.DataType == DataType.Object)
                return MethodExistsForObject(target.AsObject(), methodName);

            if (target.DataType == DataType.Type)
                return MethodExistsForType(target.GetRawValue() as TypeTypeValue, methodName);

            throw RuntimeException.InvalidArgumentType("target");
        }

        private static bool MethodExistsForObject(IRuntimeContextInstance target, string methodName)
        {
            try
            {
                var idx = target.FindMethod(methodName);
                return idx >= 0;
            }
            catch (RuntimeException)
            {
                return false;
            }
        }

        private static ValueTable.ValueTable EmptyAnnotationsTable()
        {
            var annotationsTable = new ValueTable.ValueTable();
            annotationsTable.Columns.Add("Имя");
            annotationsTable.Columns.Add("Параметры");

            return annotationsTable;
        }

        private static ValueTable.ValueTable CreateAnnotationTable(AnnotationDefinition[] annotations)
        {
            var annotationsTable = EmptyAnnotationsTable();
            var annotationNameColumn = annotationsTable.Columns.FindColumnByName("Имя");
            var annotationParamsColumn = annotationsTable.Columns.FindColumnByName("Параметры");

            foreach (var annotation in annotations)
            {
                var annotationRow = annotationsTable.Add();
                if (annotation.Name != null)
                {
                    annotationRow.Set(annotationNameColumn, ValueFactory.Create(annotation.Name));
                }

                var parametersTable = new ValueTable.ValueTable();
                var parameterNameColumn = parametersTable.Columns.Add("Имя");
                var parameterValueColumn = parametersTable.Columns.Add("Значение");

                annotationRow.Set(annotationParamsColumn, parametersTable);

                if (annotation.ParamCount != 0)
                {
                    foreach (var annotationParameter in annotation.Parameters)
                    {
                        var parameterRow = parametersTable.Add();
                        if (annotationParameter.Name != null)
                        {
                            parameterRow.Set(parameterNameColumn, ValueFactory.Create(annotationParameter.Name));
                        }
                        parameterRow.Set(parameterValueColumn, annotationParameter.RuntimeValue);
                    }
                }
            }

            return annotationsTable;
        }

        private static bool MethodExistsForType(TypeTypeValue type, string methodName)
        {
            var clrType = GetReflectableClrType(type);
            return clrType.GetMethod(methodName) != null;
        }

        private static Type GetReflectableClrType(TypeTypeValue type)
        {
            Type clrType;
            try
            {
                clrType = TypeManager.GetImplementingClass(type.Value.ID);
            }
            catch (InvalidOperationException)
            {
                throw NonReflectableType();
            }

            Type reflectableType;
            if (clrType == typeof(AttachedScriptsFactory))
                reflectableType = ReflectUserType(type.Value.Name);
            else
                reflectableType = ReflectContext(clrType);

            return reflectableType;
        }

        private static RuntimeException NonReflectableType()
        {
            return RuntimeException.InvalidArgumentValue("Тип не может быть отражен.");
        }

        /// <summary>
        /// Получает таблицу методов для переданного объекта..
        /// </summary>
        /// <param name="target">Объект, из которого получаем таблицу методов.</param>
        /// <returns>Таблица значений колонками: Имя, Количество, ЭтоФункция, Аннотации</returns>
        [ContextMethod("ПолучитьТаблицуМетодов", "GetMethodsTable")]
        public ValueTable.ValueTable GetMethodsTable(IValue target)
        {
            var result = new ValueTable.ValueTable();
            if(target.DataType == DataType.Object)
                FillMethodsTableForObject(target.AsObject(), result);
            else if (target.DataType == DataType.Type)
                FillMethodsTableForType(target.GetRawValue() as TypeTypeValue, result);
            else
                throw RuntimeException.InvalidArgumentType();

            return result;
        }

        private static void FillMethodsTableForObject(IRuntimeContextInstance target, ValueTable.ValueTable result)
        {
            FillMethodsTable(result, target.GetMethods());
        }

        private static void FillMethodsTableForType(TypeTypeValue type, ValueTable.ValueTable result)
        {
            var clrType = GetReflectableClrType(type);
            var clrMethods = clrType.GetMethods(BindingFlags.Instance|BindingFlags.NonPublic|BindingFlags.Public);
            FillMethodsTable(result, ConvertToOsMethods(clrMethods));
        }

        private static IEnumerable<MethodInfo> ConvertToOsMethods(IEnumerable<System.Reflection.MethodInfo> source)
        {
            var dest = new List<MethodInfo>();
            foreach (var methodInfo in source)
            {
                var osMethod = new MethodInfo();
                osMethod.Name = methodInfo.Name;
                osMethod.Alias = null;
                osMethod.IsExport = methodInfo.IsPublic;
                osMethod.IsFunction = methodInfo.ReturnType != typeof(void);
                osMethod.Annotations = GetAnnotations(methodInfo.GetCustomAttributes<UserAnnotationAttribute>());

                var methodParameters = methodInfo.GetParameters();
                var osParams = new ParameterDefinition[methodParameters.Length];
                osMethod.Params = osParams;
                for (int i = 0; i < osParams.Length; i++)
                {
                    var parameterInfo = methodParameters[i];
                    var osParam = new ParameterDefinition();
                    osParam.Name = parameterInfo.Name;
                    osParam.IsByValue = parameterInfo.GetCustomAttribute<ByRefAttribute>() != null;
                    osParam.HasDefaultValue = parameterInfo.HasDefaultValue;
                    osParam.DefaultValueIndex = -1;
                    osParam.DefaultValue = parameterInfo.DefaultValue as IValue;

                    // On Mono 5.20 we can't use GetCustomAttributes<T> because it fails with InvalidCast.
                    // Here's a workaround with home-made attribute Type filter.
                    var attributes = parameterInfo.GetCustomAttributes()
                        .OfType<UserAnnotationAttribute>();
                    
                    osParam.Annotations = GetAnnotations(attributes);
                    osParams[i] = osParam;
                }
                dest.Add(osMethod);
            }

            return dest;
        }

        private static AnnotationDefinition[] GetAnnotations(IEnumerable<UserAnnotationAttribute> attributes)
        {
            return attributes.Select(x => x.Annotation).ToArray();
        }

        private static void FillPropertiesTableForType(TypeTypeValue type, ValueTable.ValueTable result, bool withPrivate = false)
        {
            var clrType = GetReflectableClrType(type);
            var nativeProps = clrType.GetProperties()
                                     .Select(x => new
                                     {
                                         PropDef = x.GetCustomAttribute<ContextPropertyAttribute>(),
                                         Prop = x
                                     })
                                     .Where(x=>x.PropDef != null);

            int indices = 0;
            var infos = new List<VariableInfo>();
            foreach(var prop in nativeProps)
            {
                var info = new VariableInfo();
                info.Type = SymbolType.ContextProperty;
                info.Index = indices++;
                info.Identifier = prop.PropDef.GetName();
                info.Annotations = GetAnnotations(prop.Prop.GetCustomAttributes<UserAnnotationAttribute>());
                infos.Add(info);
            }

            if (clrType.BaseType == typeof(ScriptDrivenObject))
            {
                var flags = BindingFlags.Public;
                if (withPrivate)
                    flags |= BindingFlags.NonPublic;

                var nativeFields = clrType.GetFields(flags);
                foreach (var field in nativeFields)
                {
                    var info = new VariableInfo();
                    info.Type = SymbolType.ContextProperty;
                    info.Index = indices++;
                    info.Identifier = field.Name;
                    info.Annotations = GetAnnotations(field.GetCustomAttributes<UserAnnotationAttribute>());
                    info.IsExport = field.IsPublic;
                    infos.Add(info);
                }
            }

            FillPropertiesTable(result, infos);

        }

        private static void FillMethodsTable(ValueTable.ValueTable result, IEnumerable<MethodInfo> methods)
        {
            var nameColumn = result.Columns.Add("Имя", TypeDescription.StringType(), "Имя");
            var countColumn = result.Columns.Add("КоличествоПараметров", TypeDescription.IntegerType(), "Количество параметров");
            var isFunctionColumn = result.Columns.Add("ЭтоФункция", TypeDescription.BooleanType(), "Это функция");
            var annotationsColumn = result.Columns.Add("Аннотации", new TypeDescription(), "Аннотации");
            var paramsColumn = result.Columns.Add("Параметры", new TypeDescription(), "Параметры");
            var isExportlColumn = result.Columns.Add("Экспорт", new TypeDescription(), "Экспорт");

            foreach (var methInfo in methods)
            {
                
                ValueTableRow new_row = result.Add();
                new_row.Set(nameColumn, ValueFactory.Create(methInfo.Name));
                new_row.Set(countColumn, ValueFactory.Create(methInfo.ArgCount));
                new_row.Set(isFunctionColumn, ValueFactory.Create(methInfo.IsFunction));
                new_row.Set(isExportlColumn, ValueFactory.Create(methInfo.IsExport));

                new_row.Set(annotationsColumn, methInfo.AnnotationsCount != 0 ? CreateAnnotationTable(methInfo.Annotations) : EmptyAnnotationsTable());

                var paramTable = new ValueTable.ValueTable();
                var paramNameColumn = paramTable.Columns.Add("Имя", TypeDescription.StringType(), "Имя");
                var paramByValue = paramTable.Columns.Add("ПоЗначению", TypeDescription.BooleanType(), "По значению");
                var paramHasDefaultValue = paramTable.Columns.Add("ЕстьЗначениеПоУмолчанию", TypeDescription.BooleanType(), "Есть значение по-умолчанию");
                var paramDefaultValue = paramTable.Columns.Add("ЗначениеПоУмолчанию", null, "Значение по умолчанию");
                var paramAnnotationsColumn = paramTable.Columns.Add("Аннотации", new TypeDescription(), "Аннотации");
                
                new_row.Set(paramsColumn, paramTable);

                if (methInfo.ArgCount != 0)
                {
                    var index = 0;
                    foreach (var param in methInfo.Params)
                    {
                        var name = param.Name ?? $"param{++index}";
                        var paramRow = paramTable.Add();
                        paramRow.Set(paramNameColumn, ValueFactory.Create(name));
                        paramRow.Set(paramByValue, ValueFactory.Create(param.IsByValue));
                        paramRow.Set(paramHasDefaultValue, ValueFactory.Create(param.HasDefaultValue));
                        paramRow.Set(paramDefaultValue, param.DefaultValue); 
                        paramRow.Set(paramAnnotationsColumn, param.AnnotationsCount != 0 ? CreateAnnotationTable(param.Annotations) : EmptyAnnotationsTable());
                    }
                }
            }
        }

        /// <summary>
        /// Получает таблицу свойств для переданного объекта..
        /// </summary>
        /// <param name="target">Объект, из которого получаем таблицу свойств.</param>
        /// <param name="withPrivate">Включая приватные</param>
        /// <returns>Таблица значений с колонками - Имя, Аннотации</returns>
        [ContextMethod("ПолучитьТаблицуСвойств", "GetPropertiesTable")]
        public ValueTable.ValueTable GetPropertiesTable(IValue target, bool withPrivate = false)
        {
            ValueTable.ValueTable result = new ValueTable.ValueTable();

            if(target.DataType == DataType.Object)
                FillPropertiesTable(result, target.AsObject().GetProperties(withPrivate));
            else if (target.DataType == DataType.Type)
            {
                var type = target.GetRawValue() as TypeTypeValue;
                FillPropertiesTableForType(type, result, withPrivate);
            }
            else
                throw RuntimeException.InvalidArgumentType();

            return result;
        }

        /// <summary>
        /// Получает свойство по его имени.
        /// </summary>
        /// <param name="target">Объект, свойство которого необходимо установить.</param>
        /// <param name="prop">Имя свойства</param>
        /// <returns>Значение свойства</returns>
        [ContextMethod("ПолучитьСвойство", "GetProperty")]
        public IValue GetProperty(IRuntimeContextInstance target, string prop)
        {
            int propIdx;
            if (target is ScriptDrivenObject script)
                propIdx = script.FindAnyProperty(prop);
            else
                propIdx = target.FindProperty(prop);
            return target.GetPropValue(propIdx);
        }

        /// <summary>
        /// Устанавливает свойство по его имени.
        /// </summary>
        /// <param name="target">Объект, свойство которого необходимо установить.</param>
        /// <param name="prop">Имя свойства</param>
        /// <param name="value">Значение свойства.</param>
        [ContextMethod("УстановитьСвойство", "SetProperty")]
        public void SetProperty(IRuntimeContextInstance target, string prop, IValue value)
        {
            int propIdx;
            if (target is ScriptDrivenObject script)
                propIdx = script.FindAnyProperty(prop);
            else
                propIdx = target.FindProperty(prop);
            target.SetPropValue(propIdx, value);
        }

        private static void FillPropertiesTable(ValueTable.ValueTable result, IEnumerable<VariableInfo> properties)
        {
            var nameColumn = result.Columns.Add("Имя", TypeDescription.StringType(), "Имя");
            var annotationsColumn = result.Columns.Add("Аннотации", new TypeDescription(), "Аннотации");
            var exportColumn = result.Columns.Add("Экспорт", TypeDescription.BooleanType(), "Экспорт");
            var systemVarNames = new string[] { "этотобъект", "thisobject" };

            foreach (var propInfo in properties)
            {
                if (systemVarNames.Contains(propInfo.Identifier.ToLower())) continue;

                ValueTableRow new_row = result.Add();
                new_row.Set(nameColumn, ValueFactory.Create(propInfo.Identifier));
                
                new_row.Set(annotationsColumn, propInfo.AnnotationsCount != 0 ? CreateAnnotationTable(propInfo.Annotations) : EmptyAnnotationsTable());
                new_row.Set(exportColumn, ValueFactory.Create(propInfo.IsExport));
            }
        }

        public static Type ReflectUserType(string typeName)
        {
            LoadedModule module;
            try
            {
                module = AttachedScriptsFactory.GetModuleOfType(typeName);
            }
            catch (KeyNotFoundException)
            {
                throw NonReflectableType();
            }

            var builder = new ClassBuilder<UserScriptContextInstance>();

            return builder
                   .SetTypeName(typeName)
                   .SetModule(module)
                   .ExportDefaults()
                   .Build();
        }

        public static Type ReflectContext(Type clrType)
        {
            var attrib = clrType.GetCustomAttribute<ContextClassAttribute>();
            if (attrib == null || !typeof(ContextIValueImpl).IsAssignableFrom(clrType))
                throw NonReflectableType();

            var builderType = typeof(ClassBuilder<>).MakeGenericType(clrType);
            var builder = (IReflectedClassBuilder)Activator.CreateInstance(builderType);

            return builder.SetTypeName(attrib.GetName())
                   .ExportDefaults()
                   .Build();
        }

        /// <summary>
        /// Возвращает все известные типы
        /// </summary>
        /// <param name="filter">Структура - Условия поиска. Ключ - имя колонки, значение - искомое значение </param>
        /// <returns>
        ///  ТаблицаЗначений:
        ///    * Имя - Строка - Имя типа
        ///    * Значение - Тип - Тип
        ///    * Примитивный - Булево - Это примитивный тип 
        ///    * Пользовательский - Булево - Это пользовательский типа
        ///    * Коллекция - Булево - Это коллекция
        /// </returns>
        [ContextMethod("ИзвестныеТипы", "KnownTypes")]
        public ValueTable.ValueTable KnownTypes(StructureImpl filter = default)
        {
            var result = new ValueTable.ValueTable();

            var nameColumn = result.Columns.Add("Имя", TypeDescription.StringType());
            var valueColumn = result.Columns.Add("Значение", new TypeDescription(new List<TypeTypeValue>() { new TypeTypeValue(CommonTypes.Type) }));
            var primitiveColumn = result.Columns.Add("Примитивный", TypeDescription.BooleanType());
            var userColumn = result.Columns.Add("Пользовательский", TypeDescription.BooleanType());
            var collectionColumn = result.Columns.Add("Коллекция", TypeDescription.BooleanType());

            TypeManager.RegisteredTypes().ForEach(descriptor =>
            {
                var implementingClass = TypeManager.GetImplementingClass(descriptor.ID);
                
                var row = result.Add();
                
                row.Set(nameColumn, ValueFactory.Create(descriptor.ToString()));
                row.Set(valueColumn, new TypeTypeValue(descriptor));
                row.Set(primitiveColumn, ValueFactory.Create(implementingClass == typeof(DataType)));
                row.Set(userColumn, ValueFactory.Create(implementingClass == typeof(AttachedScriptsFactory)));
                row.Set(collectionColumn, ValueFactory.Create(
                    implementingClass.GetInterface(nameof(ICollectionContext)) != null)
                );
            });

            if (filter != default)
            {
                result = result.Copy(filter);
            }

            return result;
        }
        
        [ScriptConstructor]
        public static IRuntimeContextInstance CreateNew()
        {
            return new ReflectorContext();
        }
    }
}
